from django import forms
from .models import Recipe, Category

class RecipeForm(forms.ModelForm):
    class Meta:
        model = Recipe
        fields = ['name', 'preparation_time_minutes', 'calories', 'category', 'description']
        labels ={
            'name': 'название рецепта',
            'preparation_time_minutes': 'время приготовления',
            'calories': 'калорийность',
            'category': 'категория',
            'description': 'описание'

        }