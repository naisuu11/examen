from django.shortcuts import render, redirect, get_object_or_404
from .models import Recipe, Category
from .forms import RecipeForm

def index(request):
    recipes = Recipe.objects.select_related('category').all()
    categories = Category.objects.all()
    return render(request, 'index.html', {'recipes': recipes, 'categories': categories})

def add_data(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = RecipeForm()
    return render(request, 'add_data.html', {'form': form})


def delete_data(request, recipe_id=None):
    if request.method == 'POST' and recipe_id:
        recipe = get_object_or_404(Recipe, id=recipe_id)
        recipe.delete()
        return redirect('index')

    recipes = Recipe.objects.all()


def edit_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)

    if request.method == 'POST':
        form = RecipeForm(request.POST, instance=recipe)  # ← ключевое: instance=recipe
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = RecipeForm(instance=recipe)  # ← заполняет форму текущими данными

    return render(request, 'edit_data.html', {'form': form, 'recipe': recipe})


